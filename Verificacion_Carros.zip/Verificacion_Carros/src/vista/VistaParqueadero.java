
package vista;

import controlador.ControladorParqueadero;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.util.List;
import modelo.Vehiculo;

public class VistaParqueadero extends JFrame {
    private JTextField txtPlaca;
    private JTextField txtTipo;
    private JButton btnEntrada;
    private JButton btnSalida;
    private JLabel lblMensaje;
    private JTable tablaVehiculos;
    private DefaultTableModel modeloTabla;

    private ControladorParqueadero controlador;

    public VistaParqueadero() {
        controlador = new ControladorParqueadero();

        setTitle("Parqueadero - Entrada/Salida de Vehículos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblPlaca = new JLabel("Placa:");
        lblPlaca.setBounds(30, 20, 100, 25);
        add(lblPlaca);

        txtPlaca = new JTextField();
        txtPlaca.setBounds(90, 20, 120, 25);
        add(txtPlaca);

        JLabel lblTipo = new JLabel("Tipo:");
        lblTipo.setBounds(230, 20, 100, 25);
        add(lblTipo);

        txtTipo = new JTextField();
        txtTipo.setBounds(280, 20, 120, 25);
        add(txtTipo);

        btnEntrada = new JButton("Registrar Entrada");
        btnEntrada.setBounds(420, 20, 150, 30);
        add(btnEntrada);

        btnSalida = new JButton("Registrar Salida");
        btnSalida.setBounds(420, 60, 150, 30);
        add(btnSalida);

        lblMensaje = new JLabel("");
        lblMensaje.setBounds(30, 60, 350, 25);
        add(lblMensaje);

        // Tabla
        String[] columnas = {"Placa", "Tipo", "Hora Entrada", "Hora Salida"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaVehiculos = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaVehiculos);
        scrollPane.setBounds(30, 110, 540, 220);
        add(scrollPane);

        // Acciones
        btnEntrada.addActionListener((ActionEvent e) -> {
            String placa = txtPlaca.getText().trim();
            String tipo = txtTipo.getText().trim();
            if (!placa.isEmpty() && !tipo.isEmpty()) {
                controlador.registrarEntrada(placa, tipo);
                lblMensaje.setText("Entrada registrada: " + placa);
                txtPlaca.setText("");
                txtTipo.setText("");
                actualizarTabla();
            } else {
                lblMensaje.setText("Completa los campos de placa y tipo.");
            }
        });

        btnSalida.addActionListener((ActionEvent e) -> {
            String placa = txtPlaca.getText().trim();
            if (!placa.isEmpty()) {
                boolean exito = controlador.registrarSalida(placa);
                if (exito) {
                    lblMensaje.setText("Salida registrada para: " + placa);
                } else {
                    lblMensaje.setText("Vehículo no encontrado o ya salió.");
                }
                txtPlaca.setText("");
                txtTipo.setText("");
                actualizarTabla();
            } else {
                lblMensaje.setText("Ingresa una placa para registrar salida.");
            }
        });

        actualizarTabla(); // Cargar al iniciar
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0); // Limpiar tabla
        List<Vehiculo> vehiculos = controlador.cargarVehiculos();
        for (Vehiculo v : vehiculos) {
            modeloTabla.addRow(new Object[]{
                v.getPlaca(), v.getTipo(), v.getHoraEntrada(), v.getHoraSalida()
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VistaParqueadero().setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
