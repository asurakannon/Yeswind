/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Vehiculo;

public class ControladorParqueadero {
    private static final String ARCHIVO = "vehiculos.txt";

    public void registrarEntrada(String placa, String tipo) {
        Vehiculo vehiculo = new Vehiculo(placa, tipo);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO, true))) {
            writer.write(vehiculo.toArchivo());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean registrarSalida(String placa) {
        List<Vehiculo> vehiculos = cargarVehiculos();
        boolean encontrado = false;

        for (Vehiculo v : vehiculos) {
            if (v.getPlaca().equalsIgnoreCase(placa) && v.getHoraSalida().isEmpty()) {
                v.setHoraSalida();
                encontrado = true;
                break;
            }
        }

        if (encontrado) {
            guardarVehiculos(vehiculos);
        }

        return encontrado;
    }

    public List<Vehiculo> cargarVehiculos() {
        List<Vehiculo> lista = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                lista.add(Vehiculo.fromArchivo(linea));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private void guardarVehiculos(List<Vehiculo> vehiculos) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO))) {
            for (Vehiculo v : vehiculos) {
                writer.write(v.toArchivo());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


