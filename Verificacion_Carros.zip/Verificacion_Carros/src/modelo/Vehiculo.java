/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vehiculo {
    private String placa;
    private String tipo;
    private String horaEntrada;
    private String horaSalida;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Vehiculo(String placa, String tipo) {
        this.placa = placa;
        this.tipo = tipo;
        this.horaEntrada = LocalDateTime.now().format(FORMATTER);
        this.horaSalida = "";
    }

    public String getPlaca() { return placa; }
    public String getTipo() { return tipo; }
    public String getHoraEntrada() { return horaEntrada; }
    public String getHoraSalida() { return horaSalida; }

    public void setHoraSalida() {
        this.horaSalida = LocalDateTime.now().format(FORMATTER);
    }

    public String toArchivo() {
        return placa + ";" + tipo + ";" + horaEntrada + ";" + horaSalida;
    }

    public static Vehiculo fromArchivo(String linea) {
        String[] partes = linea.split(";");
        Vehiculo v = new Vehiculo(partes[0], partes[1]);
        v.horaEntrada = partes[2];
        if (partes.length > 3) {
            v.horaSalida = partes[3];
        }
        return v;
    }
}

